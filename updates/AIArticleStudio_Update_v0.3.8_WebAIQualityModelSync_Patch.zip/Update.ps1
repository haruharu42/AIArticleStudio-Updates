$ErrorActionPreference = 'Stop'
$scriptFile = $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($scriptFile)) { throw 'Run this file with -File .\Update.ps1' }
$packageRoot = Split-Path -Parent $scriptFile
$target = Join-Path $env:LOCALAPPDATA 'AIArticleStudio'
$python = Join-Path $target '.venv\Scripts\python.exe'
if (-not (Test-Path $python)) { throw 'Private Python environment was not found.' }
$patcher = Join-Path $packageRoot 'patch_v038.py'
if (-not (Test-Path $patcher)) { throw 'Patch script is missing.' }
& $python $patcher $target
if ($LASTEXITCODE -ne 0) { throw 'v0.3.8 patch step failed.' }
& $python -m py_compile (Join-Path $target 'src\ai_article_studio\ui\app.py')
if ($LASTEXITCODE -ne 0) { throw 'UI syntax validation failed.' }
& $python -c "import ai_article_studio; import ai_article_studio.ui.app as app; assert ai_article_studio.__version__ == '0.3.8'; assert app.web_ai_quality_for_model('ChatGPT','GPT-5.6 Sol（High）') == '高品質'; assert app.WEB_AI_DEFAULT_MODEL_BY_QUALITY['Claude']['高品質'] == 'Claude Opus 4.8（高品質）'; assert app.WEB_AI_DEFAULT_MODEL_BY_QUALITY['Gemini']['標準'] == 'Gemini 3.6 Flash（標準）'; print('UPDATE OK', ai_article_studio.__version__)"
if ($LASTEXITCODE -ne 0) { throw 'v0.3.8 validation failed.' }
Write-Host ''
Write-Host 'UPDATE SUCCESS' -ForegroundColor Green
Write-Host 'AI Article Studio v0.3.8 Web AI quality/model sync is installed.'
Write-Host 'Restart AI Article Studio.'
