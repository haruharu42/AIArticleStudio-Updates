AI Article Studio v0.3.6 auto-update test.
Adds cache-bypass support to updater manifest and package downloads.
