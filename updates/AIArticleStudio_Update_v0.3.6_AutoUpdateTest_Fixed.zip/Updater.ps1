param(
    [Parameter(Position=0)]
    [string]$Command = 'help',
    [Parameter(Position=1)]
    [string]$Value = ''
)

$ErrorActionPreference = 'Stop'
$AppRoot = Join-Path $env:LOCALAPPDATA 'AIArticleStudio'
$ConfigDir = Join-Path $AppRoot 'config'
$ConfigPath = Join-Path $ConfigDir 'updater.json'
$SrcDir = Join-Path $AppRoot 'src'
$TempRoot = Join-Path $env:TEMP 'AIArticleStudioUpdater'

function Write-Title {
    Write-Host ''
    Write-Host 'AI Article Studio Updater' -ForegroundColor Cyan
    Write-Host '-------------------------' -ForegroundColor DarkGray
}

function Get-InstalledVersion {
    $init = Join-Path $AppRoot 'src\ai_article_studio\__init__.py'
    if (-not (Test-Path $init)) { return 'unknown' }
    $text = Get-Content -LiteralPath $init -Raw -Encoding UTF8
    if ($text -match '__version__\s*=\s*["'']([^"'']+)["'']') { return $Matches[1] }
    return 'unknown'
}

function Get-Config {
    if (-not (Test-Path $ConfigPath)) {
        return [pscustomobject]@{ manifest_url = ''; channel = 'stable' }
    }
    try {
        return (Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json)
    } catch {
        throw "Updater config is invalid: $ConfigPath"
    }
}

function Save-Config([string]$ManifestUrl) {
    New-Item -ItemType Directory -Path $ConfigDir -Force | Out-Null
    $obj = [ordered]@{ manifest_url = $ManifestUrl; channel = 'stable' }
    $obj | ConvertTo-Json | Set-Content -LiteralPath $ConfigPath -Encoding UTF8
}

function Get-Manifest([string]$Url) {
    if ([string]::IsNullOrWhiteSpace($Url)) {
        throw "Online update source is not configured. Run: AIArticleStudio configure <manifest-url>"
    }
    $headers = @{ 'User-Agent' = 'AIArticleStudio-Updater/0.3.6'; 'Cache-Control' = 'no-cache'; 'Pragma' = 'no-cache' }
    $sep = if ($Url.Contains('?')) { '&' } else { '?' }
    $freshUrl = $Url + $sep + '_ts=' + [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
    try {
        return Invoke-RestMethod -Uri $freshUrl -Headers $headers -Method Get
    } catch {
        throw "Could not read update manifest: $($_.Exception.Message)"
    }
}

function Compare-Version([string]$A, [string]$B) {
    try {
        $va = [version]$A
        $vb = [version]$B
        return $va.CompareTo($vb)
    } catch {
        return [string]::Compare($A, $B, $true)
    }
}

function New-SourceBackup {
    if (-not (Test-Path $SrcDir)) { throw "Source directory not found: $SrcDir" }
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $backup = Join-Path $AppRoot "backup_auto_$stamp"
    New-Item -ItemType Directory -Path $backup -Force | Out-Null
    Copy-Item -LiteralPath $SrcDir -Destination (Join-Path $backup 'src') -Recurse -Force
    return $backup
}

function Restore-Backup([string]$Backup) {
    $backupSrc = Join-Path $Backup 'src'
    if (-not (Test-Path $backupSrc)) { throw "Backup is incomplete: $Backup" }
    if (Test-Path $SrcDir) { Remove-Item -LiteralPath $SrcDir -Recurse -Force }
    Copy-Item -LiteralPath $backupSrc -Destination $SrcDir -Recurse -Force
}

function Download-File([string]$Url, [string]$OutFile) {
    $headers = @{ 'User-Agent' = 'AIArticleStudio-Updater/0.3.6'; 'Cache-Control' = 'no-cache'; 'Pragma' = 'no-cache' }
    $sep = if ($Url.Contains('?')) { '&' } else { '?' }
    $freshUrl = $Url + $sep + '_ts=' + [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
    Invoke-WebRequest -Uri $freshUrl -Headers $headers -OutFile $OutFile -UseBasicParsing
}

function Find-UpdateScript([string]$ExtractedRoot) {
    $direct = Join-Path $ExtractedRoot 'Update.ps1'
    if (Test-Path $direct) { return $direct }
    $found = Get-ChildItem -LiteralPath $ExtractedRoot -Filter 'Update.ps1' -File -Recurse | Select-Object -First 1
    if ($null -eq $found) { throw 'Downloaded package does not contain Update.ps1.' }
    return $found.FullName
}

function Check-Update {
    $cfg = Get-Config
    $manifest = Get-Manifest $cfg.manifest_url
    $current = Get-InstalledVersion
    $latest = [string]$manifest.version
    if ([string]::IsNullOrWhiteSpace($latest)) { throw 'Manifest is missing version.' }
    Write-Host "Current : v$current"
    Write-Host "Latest  : v$latest"
    if ((Compare-Version $latest $current) -le 0) {
        Write-Host 'Already up to date.' -ForegroundColor Green
        return $false
    }
    Write-Host 'Update available.' -ForegroundColor Yellow
    return $true
}

function Install-Update {
    $cfg = Get-Config
    $manifest = Get-Manifest $cfg.manifest_url
    $current = Get-InstalledVersion
    $latest = [string]$manifest.version
    $packageUrl = [string]$manifest.package_url
    $expectedHash = ([string]$manifest.sha256).ToUpperInvariant()
    if ([string]::IsNullOrWhiteSpace($latest)) { throw 'Manifest is missing version.' }
    if ((Compare-Version $latest $current) -le 0) {
        Write-Host "Current : v$current"
        Write-Host "Latest  : v$latest"
        Write-Host 'Already up to date.' -ForegroundColor Green
        return
    }
    if ([string]::IsNullOrWhiteSpace($packageUrl)) { throw 'Manifest is missing package_url.' }
    if ([string]::IsNullOrWhiteSpace($expectedHash)) { throw 'Manifest is missing sha256.' }

    Write-Host "Current : v$current"
    Write-Host "Latest  : v$latest"
    Write-Host 'Downloading update...'
    New-Item -ItemType Directory -Path $TempRoot -Force | Out-Null
    $session = Join-Path $TempRoot ([guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $session -Force | Out-Null
    $zip = Join-Path $session 'update.zip'
    $extract = Join-Path $session 'package'
    try {
        Download-File $packageUrl $zip
        $actualHash = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToUpperInvariant()
        if ($actualHash -ne $expectedHash) {
            throw "SHA256 mismatch. Expected $expectedHash but got $actualHash"
        }
        Write-Host 'SHA256 verified.' -ForegroundColor Green
        $backup = New-SourceBackup
        Write-Host "Backup: $backup"
        New-Item -ItemType Directory -Path $extract -Force | Out-Null
        Expand-Archive -LiteralPath $zip -DestinationPath $extract -Force
        $updateScript = Find-UpdateScript $extract
        Write-Host 'Applying update...'
        try {
            & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $updateScript
            if ($LASTEXITCODE -ne 0) { throw "Update package exited with code $LASTEXITCODE" }
        } catch {
            Write-Host 'Update failed. Restoring previous source...' -ForegroundColor Yellow
            Restore-Backup $backup
            throw
        }
        Write-Host ''
        Write-Host 'AUTO UPDATE SUCCESS' -ForegroundColor Green
        Write-Host "Installed: v$(Get-InstalledVersion)"
    } finally {
        if (Test-Path $session) { Remove-Item -LiteralPath $session -Recurse -Force -ErrorAction SilentlyContinue }
    }
}

function Rollback-Latest {
    $backup = Get-ChildItem -LiteralPath $AppRoot -Directory -Filter 'backup_auto_*' -ErrorAction SilentlyContinue |
        Sort-Object Name -Descending | Select-Object -First 1
    if ($null -eq $backup) { throw 'No automatic backup was found.' }
    Write-Host "Restoring: $($backup.FullName)"
    Restore-Backup $backup.FullName
    Write-Host "ROLLBACK SUCCESS -> v$(Get-InstalledVersion)" -ForegroundColor Green
}

Write-Title
switch ($Command.ToLowerInvariant()) {
    'update' { Install-Update }
    'check' { [void](Check-Update) }
    'rollback' { Rollback-Latest }
    'configure' {
        if ([string]::IsNullOrWhiteSpace($Value)) { throw 'Usage: AIArticleStudio configure <manifest-url>' }
        Save-Config $Value
        Write-Host 'Update source saved.' -ForegroundColor Green
        Write-Host $Value
    }
    'status' {
        $cfg = Get-Config
        Write-Host "Installed version : v$(Get-InstalledVersion)"
        if ([string]::IsNullOrWhiteSpace([string]$cfg.manifest_url)) {
            Write-Host 'Update source     : not configured' -ForegroundColor Yellow
        } else {
            Write-Host "Update source     : $($cfg.manifest_url)"
        }
    }
    default {
        Write-Host 'Commands:'
        Write-Host '  AIArticleStudio status'
        Write-Host '  AIArticleStudio check'
        Write-Host '  AIArticleStudio update'
        Write-Host '  AIArticleStudio rollback'
        Write-Host '  AIArticleStudio configure <manifest-url>'
        Write-Host ''
        Write-Host 'Note: online updates require a configured release manifest URL.'
    }
}
