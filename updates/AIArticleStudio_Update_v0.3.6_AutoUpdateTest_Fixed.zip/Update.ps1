$ErrorActionPreference = 'Stop'
$scriptFile = $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($scriptFile)) { throw 'Run this file with -File .\Update.ps1' }
$packageRoot = Split-Path -Parent $scriptFile
$target = Join-Path $env:LOCALAPPDATA 'AIArticleStudio'
$srcTarget = Join-Path $target 'src\ai_article_studio'
if (-not (Test-Path $srcTarget)) { throw "AI Article Studio is not installed: $srcTarget" }

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backup = Join-Path $target "backup_v036_$stamp"
New-Item -ItemType Directory -Path $backup -Force | Out-Null
$oldInit = Join-Path $srcTarget '__init__.py'
if (Test-Path $oldInit) { Copy-Item -LiteralPath $oldInit -Destination (Join-Path $backup '__init__.py') -Force }
$oldUpdater = Join-Path $target 'Updater.ps1'
if (Test-Path $oldUpdater) { Copy-Item -LiteralPath $oldUpdater -Destination (Join-Path $backup 'Updater.ps1') -Force }

try {
    Copy-Item -LiteralPath (Join-Path $packageRoot 'src\ai_article_studio\__init__.py') -Destination $oldInit -Force
    Copy-Item -LiteralPath (Join-Path $packageRoot 'Updater.ps1') -Destination (Join-Path $target 'Updater.ps1') -Force
    $binTarget = Join-Path $target 'bin'
    New-Item -ItemType Directory -Path $binTarget -Force | Out-Null
    Copy-Item -LiteralPath (Join-Path $packageRoot 'bin\AIArticleStudio.cmd') -Destination (Join-Path $binTarget 'AIArticleStudio.cmd') -Force

    $userPath = [Environment]::GetEnvironmentVariable('Path', 'User')
    if ($null -eq $userPath) { $userPath = '' }
    $parts = @($userPath -split ';' | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    $already = $false
    foreach ($p in $parts) {
        if ($p.TrimEnd('\') -ieq $binTarget.TrimEnd('\')) { $already = $true; break }
    }
    if (-not $already) {
        $newUserPath = if ([string]::IsNullOrWhiteSpace($userPath)) { $binTarget } else { $userPath.TrimEnd(';') + ';' + $binTarget }
        [Environment]::SetEnvironmentVariable('Path', $newUserPath, 'User')
    }
    if (-not (($env:Path -split ';') -contains $binTarget)) { $env:Path = $env:Path + ';' + $binTarget }

    $configDir = Join-Path $target 'config'
    $configPath = Join-Path $configDir 'updater.json'
    if (-not (Test-Path $configPath)) {
        New-Item -ItemType Directory -Path $configDir -Force | Out-Null
        [ordered]@{ manifest_url = ''; channel = 'stable' } | ConvertTo-Json | Set-Content -LiteralPath $configPath -Encoding UTF8
    }

    $python = Join-Path $target '.venv\Scripts\python.exe'
    if (-not (Test-Path $python)) { throw 'Private Python environment was not found.' }
    & $python -c "import ai_article_studio; print('UPDATE OK', ai_article_studio.__version__)"
    if ($LASTEXITCODE -ne 0) { throw 'Python validation failed.' }

    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $target 'Updater.ps1') status
    if ($LASTEXITCODE -ne 0) { throw 'Updater self-test failed.' }
} catch {
    if (Test-Path (Join-Path $backup '__init__.py')) { Copy-Item -LiteralPath (Join-Path $backup '__init__.py') -Destination $oldInit -Force }
    if (Test-Path (Join-Path $backup 'Updater.ps1')) { Copy-Item -LiteralPath (Join-Path $backup 'Updater.ps1') -Destination (Join-Path $target 'Updater.ps1') -Force }
    throw
}

Write-Host ''
Write-Host 'UPDATE SUCCESS' -ForegroundColor Green
Write-Host 'AI Article Studio v0.3.6 Auto Update Test is installed.'
Write-Host "Backup: $backup"
Write-Host ''
Write-Host 'Close and reopen PowerShell once, then run:'
Write-Host '  AIArticleStudio status'
Write-Host ''
Write-Host 'Updater cache-bypass support is enabled.' -ForegroundColor Green
