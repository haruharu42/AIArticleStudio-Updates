AI Article Studio v0.3.5 - Auto Updater Bootstrap

This update installs the terminal updater foundation.

After installation:
1. Close and reopen PowerShell once.
2. Run:
   AIArticleStudio status

Available commands:
- AIArticleStudio status
- AIArticleStudio check
- AIArticleStudio update
- AIArticleStudio rollback
- AIArticleStudio configure <manifest-url>

Important:
Online update download requires a stable release manifest URL.
This package intentionally does NOT invent a distribution URL.
Once a GitHub Releases (or equivalent) distribution location is prepared,
configure it once and future updates can be installed with:
   AIArticleStudio update

Safety:
- SHA256 verification before applying downloaded update packages
- automatic source backup before update
- automatic rollback if a downloaded update fails
- user articles/settings/API credentials are not part of the source backup/restore
