AI Article Studio v0.3.7 Recovery 3

This package patches the existing UTF-8 app.py in place instead of replacing it.
It validates the patched Python file before completing the update.
