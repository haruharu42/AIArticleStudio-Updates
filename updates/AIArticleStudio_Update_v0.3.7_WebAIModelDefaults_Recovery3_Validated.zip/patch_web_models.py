from __future__ import annotations

import py_compile
import sys
from pathlib import Path

app_path = Path(sys.argv[1])
text = app_path.read_text(encoding="utf-8")
original = text

urls_block = '''WEB_AI_URLS = {\n    "ChatGPT": "https://chatgpt.com/",\n    "Claude": "https://claude.ai/",\n    "Gemini": "https://gemini.google.com/",\n}\n'''
models_block = '''\n# Current recommended Web AI model labels.\n# Display defaults only; users can edit the field if their plan shows a different model.\nWEB_AI_MODEL_DEFAULTS = {\n    "ChatGPT": "GPT-5.6 Sol",\n    "Claude": "Claude Sonnet 5",\n    "Gemini": "Gemini 3.6 Flash",\n    "その他": "",\n}\n'''

if "WEB_AI_MODEL_DEFAULTS = {" not in text:
    if urls_block not in text:
        raise SystemExit("Expected WEB_AI_URLS block was not found; no changes were made.")
    text = text.replace(urls_block, urls_block + models_block, 1)

old_init = '        self.vars["web_ai_model"] = tk.StringVar(value="")\n'
new_init = '        self.vars["web_ai_model"] = tk.StringVar(value=WEB_AI_MODEL_DEFAULTS["ChatGPT"])\n'
if old_init in text:
    text = text.replace(old_init, new_init, 1)
elif new_init not in text:
    raise SystemExit("Expected web_ai_model initialization was not found; no changes were made.")

old_service = '''        service = self.vars.get("web_ai_service").get() if self.vars.get("web_ai_service") else "ChatGPT"\n        if service in WEB_AI_URLS:\n            self.web_ai_open_btn.configure(text=f"{service}を開く", state="normal")\n        else:\n            self.web_ai_open_btn.configure(text="Web AIを選択してください", state="disabled")\n'''
new_service = '''        service = self.vars.get("web_ai_service").get() if self.vars.get("web_ai_service") else "ChatGPT"\n        model_var = self.vars.get("web_ai_model")\n        if model_var is not None:\n            model_var.set(WEB_AI_MODEL_DEFAULTS.get(service, ""))\n        if service in WEB_AI_URLS:\n            self.web_ai_open_btn.configure(text=f"{service}を開く", state="normal")\n        else:\n            self.web_ai_open_btn.configure(text="Web AIを選択してください", state="disabled")\n'''
if old_service in text:
    text = text.replace(old_service, new_service, 1)
elif new_service not in text:
    raise SystemExit("Expected _web_ai_service_changed block was not found; no changes were made.")

for required in ("GPT-5.6 Sol", "Claude Sonnet 5", "Gemini 3.6 Flash"):
    if required not in text:
        raise SystemExit(f"Required model label missing after patch: {required}")

tmp = app_path.with_suffix(".py.v037tmp")
tmp.write_text(text, encoding="utf-8", newline="\n")
try:
    py_compile.compile(str(tmp), doraise=True)
except Exception:
    tmp.unlink(missing_ok=True)
    raise

tmp.replace(app_path)
print("Web AI model defaults patch validated and applied.")
