$ErrorActionPreference = 'Stop'
$scriptFile = $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($scriptFile)) { throw 'Run this file with -File .\Update.ps1' }
$packageRoot = Split-Path -Parent $scriptFile
$target = Join-Path $env:LOCALAPPDATA 'AIArticleStudio'
$srcTarget = Join-Path $target 'src\ai_article_studio'
$app = Join-Path $srcTarget 'ui\app.py'
$init = Join-Path $srcTarget '__init__.py'
$python = Join-Path $target '.venv\Scripts\python.exe'
$patcher = Join-Path $packageRoot 'patch_web_models.py'

if (-not (Test-Path $app)) { throw "App source was not found: $app" }
if (-not (Test-Path $init)) { throw "Version file was not found: $init" }
if (-not (Test-Path $python)) { throw 'Private Python environment was not found.' }
if (-not (Test-Path $patcher)) { throw 'Patch helper was not found.' }

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backup = Join-Path $target "backup_v037_recovery3_$stamp"
New-Item -ItemType Directory -Path (Join-Path $backup 'ui') -Force | Out-Null
Copy-Item -LiteralPath $app -Destination (Join-Path $backup 'ui\app.py') -Force
Copy-Item -LiteralPath $init -Destination (Join-Path $backup '__init__.py') -Force

try {
    & $python $patcher $app
    if ($LASTEXITCODE -ne 0) { throw 'Web AI model patch failed.' }

    Set-Content -LiteralPath $init -Value '__version__ = "0.3.7"' -Encoding ASCII

    & $python -m py_compile $app
    if ($LASTEXITCODE -ne 0) { throw 'Installed UI syntax validation failed.' }
    & $python -c "import ai_article_studio; import ai_article_studio.ui.app; print('UPDATE OK', ai_article_studio.__version__)"
    if ($LASTEXITCODE -ne 0) { throw 'Installed module import validation failed.' }
}
catch {
    Copy-Item -LiteralPath (Join-Path $backup 'ui\app.py') -Destination $app -Force
    Copy-Item -LiteralPath (Join-Path $backup '__init__.py') -Destination $init -Force
    throw
}

Write-Host ''
Write-Host 'UPDATE SUCCESS' -ForegroundColor Green
Write-Host 'AI Article Studio v0.3.7 Web AI model defaults installed.'
Write-Host 'ChatGPT -> GPT-5.6 Sol'
Write-Host 'Claude  -> Claude Sonnet 5'
Write-Host 'Gemini  -> Gemini 3.6 Flash'
Write-Host "Backup: $backup"
