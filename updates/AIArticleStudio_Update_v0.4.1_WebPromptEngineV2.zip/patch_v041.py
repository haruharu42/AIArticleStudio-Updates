from __future__ import annotations

import shutil
import sys
from pathlib import Path

VERSION = "0.4.1"
OLD_IMPORT = "from .web_ai_prompt_builder import WebAIContext, build_final_article_prompt, build_title_prompt"
NEW_IMPORT = "from .web_ai_prompt_builder import WebAIContext\nfrom .web_prompt_engine_v2 import build_final_article_prompt_v2, build_title_prompt_v2"


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: patch_v041.py <install-root> <package-root>")

    install = Path(sys.argv[1])
    package = Path(sys.argv[2])
    core = install / "src" / "ai_article_studio" / "core"
    workflow = core / "web_ai_workflow.py"
    app = install / "src" / "ai_article_studio" / "ui" / "app.py"
    init = install / "src" / "ai_article_studio" / "__init__.py"
    payload = package / "payload" / "core"

    for path in (workflow, app, init):
        if not path.is_file():
            raise RuntimeError(f"required application file not found: {path}")
    if "# v0.4.0 Phase 3.5 integrated Web AI" not in app.read_text(encoding="utf-8"):
        raise RuntimeError("v0.4.1 requires the Phase 3.5 v0.4.0 UI integration. Update to v0.4.0 first.")

    for name in ("platform_content_strategy.py", "web_prompt_engine_v2.py"):
        src = payload / name
        if not src.is_file():
            raise RuntimeError(f"package payload missing: {name}")
        shutil.copy2(src, core / name)

    text = workflow.read_text(encoding="utf-8")
    if "build_title_prompt_v2" not in text:
        if OLD_IMPORT not in text:
            raise RuntimeError("web_ai_workflow import anchor not found")
        text = text.replace(OLD_IMPORT, NEW_IMPORT, 1)
        text = text.replace("build_title_prompt(request, ctx)", "build_title_prompt_v2(request, ctx)", 1)
        text = text.replace("build_final_article_prompt(request, selected_title, ctx)", "build_final_article_prompt_v2(request, selected_title, ctx)", 1)
        workflow.write_text(text, encoding="utf-8", newline="\n")

    init.write_text('__version__ = "0.4.1"\n', encoding="utf-8", newline="\n")
    print("v0.4.1 Web Prompt Engine v2 applied")


if __name__ == "__main__":
    main()
