from __future__ import annotations

import ast
import sys
from pathlib import Path


def fail(message: str) -> None:
    raise RuntimeError(message)


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("usage: validate_v041.py <AIArticleStudio install root>")
    root = Path(sys.argv[1])
    init = root / "src" / "ai_article_studio" / "__init__.py"
    core = root / "src" / "ai_article_studio" / "core"
    workflow = core / "web_ai_workflow.py"
    engine = core / "web_prompt_engine_v2.py"
    strategy = core / "platform_content_strategy.py"
    app = root / "src" / "ai_article_studio" / "ui" / "app.py"

    for path in (init, workflow, engine, strategy, app):
        if not path.is_file():
            fail(f"missing required file: {path}")
        if path.suffix == ".py":
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))

    if '__version__ = "0.4.1"' not in init.read_text(encoding="utf-8"):
        fail("version is not v0.4.1")
    workflow_text = workflow.read_text(encoding="utf-8")
    for marker in ("build_title_prompt_v2", "build_final_article_prompt_v2", "web_prompt_engine_v2"):
        if marker not in workflow_text:
            fail(f"workflow missing v2 marker: {marker}")
    engine_text = engine.read_text(encoding="utf-8")
    for marker in ("【ARTICLE BRIEF】", "【挿絵モジュール】", "販売数、ランキング", "build_final_article_prompt_v2"):
        if marker not in engine_text:
            fail(f"prompt engine missing marker: {marker}")
    strategy_text = strategy.read_text(encoding="utf-8")
    for marker in ('"note"', '"Tips"', '"Brain"', "高価格ほど情報量ではなく"):
        if marker not in strategy_text:
            fail(f"platform strategy missing marker: {marker}")
    print("V0.4.1 WEB PROMPT ENGINE V2 VALIDATION OK")


if __name__ == "__main__":
    main()
