AI Article Studio v0.3.6 - Auto Update Test

Purpose: verify GitHub manifest download, SHA256 validation, backup, package apply, and version detection.
No article-generation/UI logic changes in this test package.
