$ErrorActionPreference = 'Stop'
$scriptFile = $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($scriptFile)) { throw 'Run this file with -File .\Update.ps1' }
$packageRoot = Split-Path -Parent $scriptFile
$target = Join-Path $env:LOCALAPPDATA 'AIArticleStudio'
$srcTarget = Join-Path $target 'src\ai_article_studio'
if (-not (Test-Path $srcTarget)) { throw "AI Article Studio is not installed: $srcTarget" }

$python = Join-Path $target '.venv\Scripts\python.exe'
if (-not (Test-Path $python)) { throw 'Private Python environment was not found.' }

Copy-Item -LiteralPath (Join-Path $packageRoot 'src\ai_article_studio\__init__.py') -Destination (Join-Path $srcTarget '__init__.py') -Force
Copy-Item -LiteralPath (Join-Path $packageRoot 'src\ai_article_studio\update_probe.py') -Destination (Join-Path $srcTarget 'update_probe.py') -Force

& $python -c "import ai_article_studio; from ai_article_studio.update_probe import AUTO_UPDATE_TEST_OK; assert ai_article_studio.__version__ == '0.3.6'; assert AUTO_UPDATE_TEST_OK; print('AUTO UPDATE PACKAGE OK', ai_article_studio.__version__)"
if ($LASTEXITCODE -ne 0) { throw 'v0.3.6 validation failed.' }

Write-Host ''
Write-Host 'UPDATE PACKAGE SUCCESS' -ForegroundColor Green
Write-Host 'AI Article Studio v0.3.6 Auto Update Test installed.'
