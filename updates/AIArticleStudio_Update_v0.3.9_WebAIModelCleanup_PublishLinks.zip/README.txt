AI Article Studio v0.3.9

Changes:
- Standard ChatGPT Web choices exclude Sol Pro, Terra, and Luna.
- Quality and model dropdowns stay synchronized in both directions.
- ChatGPT mapping: Fast=GPT-5.5 Instant, Standard=GPT-5.6 Sol Medium, High=GPT-5.6 Sol High.
- Added browser launch buttons for note, Tips, and Brain in preview and Web AI completion flow.
- Update validation uses UTF-8 Python files instead of non-ASCII inline python -c commands.
