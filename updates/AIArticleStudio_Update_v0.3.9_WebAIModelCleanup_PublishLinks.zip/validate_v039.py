from __future__ import annotations

import importlib
import sys
from pathlib import Path


def fail(message: str) -> None:
    print("VALIDATION ERROR:", message)
    raise SystemExit(1)


def main() -> None:
    if len(sys.argv) != 2:
        fail("usage: validate_v039.py <AIArticleStudio install root>")
    install = Path(sys.argv[1])
    src = install / "src"
    sys.path.insert(0, str(src))
    import ai_article_studio
    app = importlib.import_module("ai_article_studio.ui.app")

    if ai_article_studio.__version__ != "0.3.9":
        fail(f"wrong version: {ai_article_studio.__version__}")

    chat = app.WEB_AI_MODEL_OPTIONS.get("ChatGPT", [])
    expected = ["GPT-5.5 Instant", "GPT-5.6 Sol（Medium）", "GPT-5.6 Sol（High）"]
    if chat != expected:
        fail(f"unexpected ChatGPT model options: {chat!r}")
    joined = " ".join(chat).lower()
    for banned in ("sol pro", "terra", "luna"):
        if banned in joined:
            fail(f"banned ChatGPT candidate remains: {banned}")

    checks = {
        ("ChatGPT", "速さ優先"): "GPT-5.5 Instant",
        ("ChatGPT", "標準"): "GPT-5.6 Sol（Medium）",
        ("ChatGPT", "高品質"): "GPT-5.6 Sol（High）",
        ("Claude", "標準"): "Claude Sonnet 5",
        ("Gemini", "標準"): "Gemini 3.6 Flash",
    }
    for (service, quality), model in checks.items():
        got = app.WEB_AI_DEFAULT_MODEL_BY_QUALITY.get(service, {}).get(quality)
        if got != model:
            fail(f"mapping mismatch {service}/{quality}: {got!r}")
        back = app.WEB_AI_QUALITY_BY_MODEL.get(service, {}).get(model)
        if back != quality:
            fail(f"reverse mapping mismatch {service}/{model}: {back!r}")

    expected_urls = {
        "note": "https://note.com/",
        "Tips": "https://tips.jp/",
        "Brain": "https://brain-market.com/",
    }
    if app.PUBLISH_PLATFORM_URLS != expected_urls:
        fail(f"publishing URLs mismatch: {app.PUBLISH_PLATFORM_URLS!r}")

    print("UPDATE OK 0.3.9")


if __name__ == "__main__":
    main()
