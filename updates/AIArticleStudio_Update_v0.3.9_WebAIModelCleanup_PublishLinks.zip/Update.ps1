$ErrorActionPreference = 'Stop'
$scriptFile = $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($scriptFile)) { throw 'Run this file with -File .\Update.ps1' }
$packageRoot = Split-Path -Parent $scriptFile
$target = Join-Path $env:LOCALAPPDATA 'AIArticleStudio'
$appFile = Join-Path $target 'src\ai_article_studio\ui\app.py'
$initFile = Join-Path $target 'src\ai_article_studio\__init__.py'
$python = Join-Path $target '.venv\Scripts\python.exe'
if (-not (Test-Path $appFile)) { throw "AI Article Studio is not installed: $appFile" }
if (-not (Test-Path $initFile)) { throw "AI Article Studio version file was not found: $initFile" }
if (-not (Test-Path $python)) { throw 'Private Python environment was not found.' }

& $python (Join-Path $packageRoot 'patch_v039.py') $target
if ($LASTEXITCODE -ne 0) { throw 'v0.3.9 patch failed.' }

& $python -m py_compile $appFile
if ($LASTEXITCODE -ne 0) { throw 'v0.3.9 Python compile validation failed.' }

& $python (Join-Path $packageRoot 'validate_v039.py') $target
if ($LASTEXITCODE -ne 0) { throw 'v0.3.9 feature validation failed.' }

Write-Host ''
Write-Host 'UPDATE SUCCESS' -ForegroundColor Green
Write-Host 'AI Article Studio v0.3.9 is installed.'
Write-Host 'Web AI quality/model sync updated; Sol Pro/Terra/Luna hidden from standard ChatGPT choices.'
Write-Host 'note / Tips / Brain launch buttons added.'
Write-Host 'Restart AI Article Studio.'
