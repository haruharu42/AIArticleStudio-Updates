from __future__ import annotations

import re
import sys
from pathlib import Path

MARKER = "# v0.3.9 Web AI quality/model sync + publish links"

CONSTANTS = r'''# v0.3.9 Web AI quality/model sync + publish links
WEB_AI_MODEL_OPTIONS = {
    "ChatGPT": ["GPT-5.5 Instant", "GPT-5.6 Sol（Medium）", "GPT-5.6 Sol（High）"],
    "Claude": ["Claude Haiku 4.5", "Claude Sonnet 5", "Claude Opus 4.8"],
    "Gemini": ["Gemini 3.5 Flash-Lite", "Gemini 3.6 Flash", "Gemini 3.1 Pro Preview"],
}
WEB_AI_DEFAULT_MODEL_BY_QUALITY = {
    "ChatGPT": {"速さ優先": "GPT-5.5 Instant", "標準": "GPT-5.6 Sol（Medium）", "高品質": "GPT-5.6 Sol（High）"},
    "Claude": {"速さ優先": "Claude Haiku 4.5", "標準": "Claude Sonnet 5", "高品質": "Claude Opus 4.8"},
    "Gemini": {"速さ優先": "Gemini 3.5 Flash-Lite", "標準": "Gemini 3.6 Flash", "高品質": "Gemini 3.1 Pro Preview"},
}
WEB_AI_QUALITY_BY_MODEL = {
    service: {model: quality for quality, model in mapping.items()}
    for service, mapping in WEB_AI_DEFAULT_MODEL_BY_QUALITY.items()
}
PUBLISH_PLATFORM_URLS = {
    "note": "https://note.com/",
    "Tips": "https://tips.jp/",
    "Brain": "https://brain-market.com/",
}
'''

WEB_SETTINGS = r'''        self.web_settings_card = self.card(body, bg=SURFACE_2)
        self._section_title(self.web_settings_card, "WEB", "Web版AIの設定", "使用するAI・生成品質・モデルを連動して選べます")
        webgrid = tk.Frame(self.web_settings_card, bg=SURFACE_2)
        webgrid.pack(fill="x", padx=20, pady=(0,12)); webgrid.grid_columnconfigure(1,weight=1); webgrid.grid_columnconfigure(3,weight=1)
        self.vars["web_ai_service"] = tk.StringVar(value="ChatGPT")
        self.vars["web_ai_quality"] = tk.StringVar(value="標準")
        self.vars["web_ai_model"] = tk.StringVar(value="GPT-5.6 Sol（Medium）")
        self._label(webgrid,"使用するWeb AI",size=9,fg=SOFT,bg=SURFACE_2).grid(row=0,column=0,sticky="w",padx=(0,8),pady=6)
        self.web_ai_cb = ttk.Combobox(webgrid,textvariable=self.vars["web_ai_service"],values=["ChatGPT","Claude","Gemini","その他"],state="readonly",style="Dark.TCombobox")
        self.web_ai_cb.grid(row=0,column=1,sticky="ew",padx=(0,16),pady=6)
        self.web_ai_cb.bind("<<ComboboxSelected>>", self._web_ai_service_changed)
        self._label(webgrid,"生成品質",size=9,fg=SOFT,bg=SURFACE_2).grid(row=0,column=2,sticky="w",padx=(0,8),pady=6)
        self.web_ai_quality_cb = ttk.Combobox(webgrid,textvariable=self.vars["web_ai_quality"],values=["速さ優先","標準","高品質"],state="readonly",style="Dark.TCombobox")
        self.web_ai_quality_cb.grid(row=0,column=3,sticky="ew",pady=6)
        self.web_ai_quality_cb.bind("<<ComboboxSelected>>", self._web_ai_quality_changed)
        self._label(webgrid,"モデル / 推論モード",size=9,fg=SOFT,bg=SURFACE_2).grid(row=1,column=0,sticky="w",padx=(0,8),pady=6)
        self.web_ai_model_cb = ttk.Combobox(webgrid,textvariable=self.vars["web_ai_model"],values=WEB_AI_MODEL_OPTIONS["ChatGPT"],state="readonly",style="Dark.TCombobox")
        self.web_ai_model_cb.grid(row=1,column=1,columnspan=3,sticky="ew",pady=6)
        self.web_ai_model_cb.bind("<<ComboboxSelected>>", self._web_ai_model_changed)
        self.web_ai_model_note = self._label(webgrid,"ChatGPT通常会話向け。Sol Pro / Terra / Luna は候補に表示しません。",size=8,fg=MUTED,bg=SURFACE_2)
        self.web_ai_model_note.grid(row=2,column=1,columnspan=3,sticky="w",pady=(0,4))
        guide=tk.Frame(self.web_settings_card,bg="#131B31",highlightthickness=1,highlightbackground="#2E315C")
        guide.pack(fill="x",padx=20,pady=(0,16))
        self._label(guide,"💡 チャットの使い方",size=9,bold=True,fg="#C4B5FD",bg="#131B31").pack(anchor="w",padx=12,pady=(10,4))
        self._label(guide,"新しい記事は『1記事につき1チャット』がおすすめです。同じ記事の修正・特典追加は同じチャットでもOKです。完成記事用プロンプトは自己完結型なので、新しいチャットに貼っても使えます。",size=8,fg=SOFT,bg="#131B31",wraplength=760,justify="left").pack(anchor="w",padx=12,pady=(0,8))
        openrow = tk.Frame(guide, bg="#131B31")
        openrow.pack(fill="x", padx=12, pady=(0,10))
        self.web_ai_open_btn = self._primary_button(openrow,"ChatGPTを開く",self._open_selected_web_ai)
        self.web_ai_open_btn.pack(side="left")
        self._secondary_button(openrow,"ChatGPT",lambda:self._open_web_ai_site("ChatGPT")).pack(side="left",padx=(8,4))
        self._secondary_button(openrow,"Claude",lambda:self._open_web_ai_site("Claude")).pack(side="left",padx=4)
        self._secondary_button(openrow,"Gemini",lambda:self._open_web_ai_site("Gemini")).pack(side="left",padx=4)
        self._label(guide,"※ 外部ブラウザで公式Web版を開きます。ログインや送信操作はアプリから自動操作しません。",size=8,fg=MUTED,bg="#131B31").pack(anchor="w",padx=12,pady=(0,10))

        # Basic settings
'''

METHODS = r'''    def _web_ai_service_changed(self, _event=None):
        service = self.vars.get("web_ai_service").get() if self.vars.get("web_ai_service") else "ChatGPT"
        if hasattr(self, "web_ai_open_btn"):
            if service in WEB_AI_URLS:
                self.web_ai_open_btn.configure(text=f"{service}を開く", state="normal")
            else:
                self.web_ai_open_btn.configure(text="Web AIを選択してください", state="disabled")
        if not hasattr(self, "web_ai_model_cb"):
            return
        if service in WEB_AI_MODEL_OPTIONS:
            self.web_ai_model_cb.configure(values=WEB_AI_MODEL_OPTIONS[service], state="readonly")
            quality = self.vars.get("web_ai_quality").get() if self.vars.get("web_ai_quality") else "標準"
            model = WEB_AI_DEFAULT_MODEL_BY_QUALITY[service].get(quality, WEB_AI_MODEL_OPTIONS[service][0])
            self.vars["web_ai_model"].set(model)
            if hasattr(self, "web_ai_model_note"):
                note = "ChatGPT通常会話向け。Sol Pro / Terra / Luna は候補に表示しません。" if service == "ChatGPT" else "生成品質とモデルは双方向で連動します。"
                self.web_ai_model_note.configure(text=note)
        else:
            self.web_ai_model_cb.configure(values=(), state="normal")
            self.vars["web_ai_model"].set("")
            if hasattr(self, "web_ai_model_note"):
                self.web_ai_model_note.configure(text="その他のWeb AIではモデル名を自由入力できます。")

    def _web_ai_quality_changed(self, _event=None):
        service = self.vars.get("web_ai_service").get() if self.vars.get("web_ai_service") else "ChatGPT"
        quality = self.vars.get("web_ai_quality").get() if self.vars.get("web_ai_quality") else "標準"
        mapping = WEB_AI_DEFAULT_MODEL_BY_QUALITY.get(service)
        if mapping and quality in mapping and self.vars.get("web_ai_model"):
            self.vars["web_ai_model"].set(mapping[quality])

    def _web_ai_model_changed(self, _event=None):
        service = self.vars.get("web_ai_service").get() if self.vars.get("web_ai_service") else "ChatGPT"
        model = self.vars.get("web_ai_model").get() if self.vars.get("web_ai_model") else ""
        quality = WEB_AI_QUALITY_BY_MODEL.get(service, {}).get(model)
        if quality and self.vars.get("web_ai_quality"):
            self.vars["web_ai_quality"].set(quality)

    def _open_web_ai_site(self, service: str):
        url = WEB_AI_URLS.get(service)
        if not url:
            messagebox.showinfo("Web版AI", "ChatGPT / Claude / Gemini から選択してください。")
            return
        try:
            webbrowser.open_new_tab(url)
        except Exception as e:
            messagebox.showerror("Web版AI", f"ブラウザを開けませんでした。\n{e}")

    def _open_selected_web_ai(self):
        service = self.vars.get("web_ai_service").get() if self.vars.get("web_ai_service") else "ChatGPT"
        self._open_web_ai_site(service)

    def _open_publish_platform(self, platform: str):
        url = PUBLISH_PLATFORM_URLS.get(platform)
        if not url:
            messagebox.showinfo("掲載先", "note / Tips / Brain から選択してください。")
            return
        try:
            webbrowser.open_new_tab(url)
        except Exception as e:
            messagebox.showerror("掲載先", f"ブラウザを開けませんでした。\n{e}")

    def _genre_changed(self, _event=None):
'''

RESULT_LINKS = r'''        self._secondary_button(ptop, "Markdown保存", self.export_current).pack(side="right")
        publish_nav = tk.Frame(self.result_card, bg=SURFACE)
        publish_nav.pack(fill="x", padx=20, pady=(0,8))
        self._label(publish_nav, "掲載先を開く", size=8, fg=MUTED).pack(side="left", padx=(0,8))
        self._secondary_button(publish_nav, "note", lambda:self._open_publish_platform("note")).pack(side="left", padx=(0,4))
        self._secondary_button(publish_nav, "Tips", lambda:self._open_publish_platform("Tips")).pack(side="left", padx=4)
        self._secondary_button(publish_nav, "Brain", lambda:self._open_publish_platform("Brain")).pack(side="left", padx=4)
'''

STEP4_LINKS = r'''        self._secondary_button(controls4,"元＋掲載用を保存",save_markdown).pack(side="left")
        publish_links=tk.Frame(step4,bg=SURFACE)
        publish_links.pack(fill="x",padx=18,pady=(0,14))
        self._label(publish_links,"掲載先を開く",size=8,fg=MUTED).pack(side="left",padx=(0,8))
        self._secondary_button(publish_links,"note",lambda:self._open_publish_platform("note")).pack(side="left",padx=(0,4))
        self._secondary_button(publish_links,"Tips",lambda:self._open_publish_platform("Tips")).pack(side="left",padx=4)
        self._secondary_button(publish_links,"Brain",lambda:self._open_publish_platform("Brain")).pack(side="left",padx=4)
'''


def replace_once(text: str, pattern: str, replacement: str, label: str, flags=0) -> str:
    new, count = re.subn(pattern, lambda _m: replacement, text, count=1, flags=flags)
    if count != 1:
        raise RuntimeError(f"patch target not found or ambiguous: {label} ({count})")
    return new


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("usage: patch_v039.py <AIArticleStudio install root>")
    install = Path(sys.argv[1])
    app_path = install / "src" / "ai_article_studio" / "ui" / "app.py"
    init_path = install / "src" / "ai_article_studio" / "__init__.py"
    text = app_path.read_text(encoding="utf-8")

    # Remove a previous v0.3.9 constants block if re-applied, then make our mapping the last assignment before class App.
    text = re.sub(r"\n# v0\.3\.9 Web AI quality/model sync \+ publish links\nWEB_AI_MODEL_OPTIONS = \{.*?\nPUBLISH_PLATFORM_URLS = \{.*?\n\}\n", "\n", text, count=1, flags=re.S)
    class_pos = text.find("\n\nclass App(tk.Tk):")
    if class_pos < 0:
        raise RuntimeError("class App marker not found")
    text = text[:class_pos] + "\n\n" + CONSTANTS.rstrip() + text[class_pos:]

    # Replace the complete Web AI settings UI, independent of older default-model patches.
    text = replace_once(
        text,
        r"        self\.web_settings_card = self\.card\(body, bg=SURFACE_2\)\n.*?        # Basic settings\n",
        WEB_SETTINGS,
        "Web AI settings block",
        flags=re.S,
    )

    # Replace all Web-AI helper methods through the start of _genre_changed.
    text = replace_once(
        text,
        r"    def _web_ai_service_changed\(self, _event=None\):\n.*?    def _genre_changed\(self, _event=None\):\n",
        METHODS,
        "Web AI helper methods",
        flags=re.S,
    )

    # Main article preview: add publishing-site launch buttons.
    if 'publish_nav = tk.Frame(self.result_card, bg=SURFACE)' not in text:
        text = replace_once(
            text,
            r'        self\._secondary_button\(ptop, "Markdown保存", self\.export_current\)\.pack\(side="right"\)\n',
            RESULT_LINKS,
            "main preview publish links",
        )

    # Web AI final step: add publishing-site launch buttons.
    if 'publish_links=tk.Frame(step4,bg=SURFACE)' not in text:
        text = replace_once(
            text,
            r'        self\._secondary_button\(controls4,"元＋掲載用を保存",save_markdown\)\.pack\(side="left"\)\n',
            STEP4_LINKS,
            "Web AI final publish links",
        )

    # Do not leave standard ChatGPT candidates that the user asked to hide.
    # Old constants can remain above our v0.3.9 block, but UI must only reference our mapping.
    app_path.write_text(text, encoding="utf-8", newline="\n")
    init_path.write_text('__version__ = "0.3.9"\n', encoding="utf-8", newline="\n")
    print("v0.3.9 patch applied")


if __name__ == "__main__":
    main()
