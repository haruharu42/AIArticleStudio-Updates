$ErrorActionPreference = 'Stop'
$target = Join-Path $env:LOCALAPPDATA 'AIArticleStudio'
$app = Join-Path $target 'src\ai_article_studio\ui\app.py'
$init = Join-Path $target 'src\ai_article_studio\__init__.py'
if (-not (Test-Path $app)) { throw "AI Article Studio UI file not found: $app" }

$text = [System.IO.File]::ReadAllText($app)

$oldModel = 'self.vars["web_ai_model"] = tk.StringVar(value="")'
$newModel = 'self.vars["web_ai_model"] = tk.StringVar(value="GPT-5.6 Sol")'
if ($text.Contains($oldModel)) { $text = $text.Replace($oldModel, $newModel) }

$oldBind = 'self.web_ai_cb.bind("<<ComboboxSelected>>", self._web_ai_service_changed)'
$newBind = 'self.web_ai_cb.bind("<<ComboboxSelected>>", self._on_web_ai_service_changed)' + [Environment]::NewLine + '        ' + $oldBind
if (-not $text.Contains('_on_web_ai_service_changed')) {
    if (-not $text.Contains($oldBind)) { throw 'Web AI selector binding was not found.' }
    $text = $text.Replace($oldBind, $newBind)
}

if (-not $text.Contains('def _on_web_ai_service_changed')) {
$marker = '    def _set_generation_mode(self, value: str):'
$method = @'
    def _on_web_ai_service_changed(self, event=None):
        latest_models = {
            "ChatGPT": "GPT-5.6 Sol",
            "Claude": "Claude Sonnet 5",
            "Gemini": "Gemini 3.6 Flash",
            "その他": "",
        }
        service_var = self.vars.get("web_ai_service")
        model_var = self.vars.get("web_ai_model")
        service = service_var.get() if service_var is not None else ""
        if model_var is not None:
            model_var.set(latest_models.get(service, ""))


'@
    if (-not $text.Contains($marker)) { throw 'Generation mode method marker was not found.' }
    $text = $text.Replace($marker, $method + $marker)
}

[System.IO.File]::WriteAllText($app, $text, (New-Object System.Text.UTF8Encoding($false)))
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'src\ai_article_studio\__init__.py') -Destination $init -Force

$python = Join-Path $target '.venv\Scripts\python.exe'
if (-not (Test-Path $python)) { throw 'Private Python environment was not found.' }
& $python -m py_compile $app
if ($LASTEXITCODE -ne 0) { throw 'UI syntax validation failed.' }
& $python -c "import ai_article_studio; assert ai_article_studio.__version__ == '0.3.7'; print('UPDATE OK', ai_article_studio.__version__)"
if ($LASTEXITCODE -ne 0) { throw 'Version validation failed.' }
Write-Host 'v0.3.7 Web AI model defaults patch installed.' -ForegroundColor Green
