AI Article Studio v0.3.7 recovery package
- Patches Web AI model defaults in the installed UI file.
- Keeps user data untouched.
- Validates Python syntax after patching.
