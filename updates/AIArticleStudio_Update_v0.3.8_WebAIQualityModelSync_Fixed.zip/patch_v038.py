from __future__ import annotations
import re, sys
from pathlib import Path

VERSION = "0.3.8"
CONSTANTS = '''
# Web AI model choices. Actual availability can vary by plan and provider rollout.
WEB_AI_MODEL_PROFILES = {
    "ChatGPT": [
        ("GPT-5.6 Sol（Instant）", "速さ優先"),
        ("GPT-5.6 Sol（Medium）", "標準"),
        ("GPT-5.6 Sol（High）", "高品質"),
        ("GPT-5.6 Sol Pro（Pro向け）", "高品質"),
        ("GPT-5.6 Luna（Free向け）", "速さ優先"),
    ],
    "Claude": [
        ("Claude Haiku 4.5（速さ優先）", "速さ優先"),
        ("Claude Sonnet 5（標準）", "標準"),
        ("Claude Sonnet 5（高Effort）", "高品質"),
        ("Claude Opus 4.8（高品質）", "高品質"),
    ],
    "Gemini": [
        ("Gemini 3.5 Flash-Lite（速さ優先）", "速さ優先"),
        ("Gemini 3.6 Flash（標準）", "標準"),
        ("Gemini 3.5 Flash（標準・別候補）", "標準"),
        ("Gemini 3.1 Pro Preview（高品質）", "高品質"),
    ],
}
WEB_AI_DEFAULT_MODEL_BY_QUALITY = {
    "ChatGPT": {"速さ優先": "GPT-5.6 Sol（Instant）", "標準": "GPT-5.6 Sol（Medium）", "高品質": "GPT-5.6 Sol（High）"},
    "Claude": {"速さ優先": "Claude Haiku 4.5（速さ優先）", "標準": "Claude Sonnet 5（標準）", "高品質": "Claude Opus 4.8（高品質）"},
    "Gemini": {"速さ優先": "Gemini 3.5 Flash-Lite（速さ優先）", "標準": "Gemini 3.6 Flash（標準）", "高品質": "Gemini 3.1 Pro Preview（高品質）"},
}
def web_ai_models_for(service: str):
    return [name for name, _quality in WEB_AI_MODEL_PROFILES.get(service, [])]
def web_ai_quality_for_model(service: str, model: str):
    for name, quality in WEB_AI_MODEL_PROFILES.get(service, []):
        if name == model:
            return quality
    return None
'''
UI_BLOCK = '''        self.vars["web_ai_service"] = tk.StringVar(value="ChatGPT")
        self.vars["web_ai_quality"] = tk.StringVar(value="標準")
        self.vars["web_ai_model"] = tk.StringVar(value=WEB_AI_DEFAULT_MODEL_BY_QUALITY["ChatGPT"]["標準"])
        self._label(webgrid,"使用するWeb AI",size=9,fg=SOFT,bg=SURFACE_2).grid(row=0,column=0,sticky="w",padx=(0,8),pady=6)
        self.web_ai_cb = ttk.Combobox(webgrid,textvariable=self.vars["web_ai_service"],values=["ChatGPT","Claude","Gemini","その他"],state="readonly",style="Dark.TCombobox")
        self.web_ai_cb.grid(row=0,column=1,sticky="ew",padx=(0,16),pady=6)
        self.web_ai_cb.bind("<<ComboboxSelected>>", self._web_ai_service_changed)
        self._label(webgrid,"生成品質",size=9,fg=SOFT,bg=SURFACE_2).grid(row=0,column=2,sticky="w",padx=(0,8),pady=6)
        self.web_ai_quality_cb = ttk.Combobox(webgrid,textvariable=self.vars["web_ai_quality"],values=["速さ優先","標準","高品質"],state="readonly",style="Dark.TCombobox")
        self.web_ai_quality_cb.grid(row=0,column=3,sticky="ew",pady=6)
        self.web_ai_quality_cb.bind("<<ComboboxSelected>>", self._web_ai_quality_changed)
        self._label(webgrid,"モデル / 推論モード",size=9,fg=SOFT,bg=SURFACE_2).grid(row=1,column=0,sticky="w",padx=(0,8),pady=6)
        self.web_ai_model_cb = ttk.Combobox(webgrid,textvariable=self.vars["web_ai_model"],values=web_ai_models_for("ChatGPT"),state="readonly",style="Dark.TCombobox")
        self.web_ai_model_cb.grid(row=1,column=1,columnspan=3,sticky="ew",pady=6)
        self.web_ai_model_cb.bind("<<ComboboxSelected>>", self._web_ai_model_changed)
        self.web_ai_model_note = self._label(webgrid,"品質を変えると推奨モデルへ自動変更。モデルを変えると品質も自動連動します。利用可否は各Web AIのプランにより異なります。",size=8,fg=MUTED,bg=SURFACE_2,wraplength=760,justify="left")
        self.web_ai_model_note.grid(row=2,column=1,columnspan=3,sticky="w",pady=(0,4))
'''
METHODS = '''    def _web_ai_service_changed(self, _event=None):
        service = self.vars.get("web_ai_service").get() if self.vars.get("web_ai_service") else "ChatGPT"
        if hasattr(self, "web_ai_open_btn"):
            if service in WEB_AI_URLS:
                self.web_ai_open_btn.configure(text=f"{service}を開く", state="normal")
            else:
                self.web_ai_open_btn.configure(text="Web AIを選択してください", state="disabled")
        if not hasattr(self, "web_ai_model_cb"):
            return
        quality = self.vars.get("web_ai_quality").get() if self.vars.get("web_ai_quality") else "標準"
        if service in WEB_AI_MODEL_PROFILES:
            models = web_ai_models_for(service)
            self.web_ai_model_cb.configure(values=models, state="readonly")
            preferred = WEB_AI_DEFAULT_MODEL_BY_QUALITY.get(service, {}).get(quality)
            if preferred not in models:
                preferred = models[0] if models else ""
            self.vars["web_ai_model"].set(preferred or "")
        else:
            self.web_ai_model_cb.configure(values=[], state="normal")
            self.vars["web_ai_model"].set("")

    def _web_ai_quality_changed(self, _event=None):
        service = self.vars.get("web_ai_service").get() if self.vars.get("web_ai_service") else "ChatGPT"
        quality = self.vars.get("web_ai_quality").get() if self.vars.get("web_ai_quality") else "標準"
        preferred = WEB_AI_DEFAULT_MODEL_BY_QUALITY.get(service, {}).get(quality)
        if preferred and self.vars.get("web_ai_model"):
            self.vars["web_ai_model"].set(preferred)

    def _web_ai_model_changed(self, _event=None):
        service = self.vars.get("web_ai_service").get() if self.vars.get("web_ai_service") else "ChatGPT"
        model = self.vars.get("web_ai_model").get() if self.vars.get("web_ai_model") else ""
        quality = web_ai_quality_for_model(service, model)
        if quality and self.vars.get("web_ai_quality"):
            self.vars["web_ai_quality"].set(quality)

'''

def patch_app(path: Path):
    text = path.read_text(encoding="utf-8")
    class_pos = text.find("\n\nclass App(")
    if class_pos < 0: raise RuntimeError("Could not locate App class")
    marker = text.find("# Web AI model choices")
    if marker >= 0 and marker < class_pos:
        text = text[:marker] + CONSTANTS.lstrip("\n") + text[class_pos:]
    elif "WEB_AI_MODEL_PROFILES =" not in text:
        text = text[:class_pos] + CONSTANTS + text[class_pos:]
    ui_start = text.find('        self.vars["web_ai_service"] = ')
    ui_end = text.find('        guide=tk.Frame', ui_start)
    if ui_start < 0 or ui_end < 0: raise RuntimeError("Could not locate Web AI settings block")
    text = text[:ui_start] + UI_BLOCK + text[ui_end:]
    m_start = text.find("    def _web_ai_service_changed")
    m_end = text.find("    def _open_web_ai_site", m_start)
    if m_start < 0 or m_end < 0: raise RuntimeError("Could not locate Web AI service handler")
    text = text[:m_start] + METHODS + text[m_end:]
    text = text.replace("使用するAIと品質を選びます。モデル名はWeb側で選択してください", "使用するAI・生成品質・モデルを連動して選べます。実際のモデルはWeb側で選択してください")
    compile(text, str(path), "exec")
    path.write_text(text, encoding="utf-8", newline="\n")

def patch_init(path: Path):
    text = path.read_text(encoding="utf-8")
    new = re.sub(r'__version__\s*=\s*["\'][^"\']+["\']', f'__version__ = "{VERSION}"', text, count=1)
    if new == text and f'__version__ = "{VERSION}"' not in text: raise RuntimeError("Could not update version marker")
    path.write_text(new, encoding="utf-8", newline="\n")

def main():
    if len(sys.argv) != 2: return 2
    install = Path(sys.argv[1])
    app = install / "src" / "ai_article_studio" / "ui" / "app.py"
    init = install / "src" / "ai_article_studio" / "__init__.py"
    if not app.exists() or not init.exists(): raise RuntimeError("AI Article Studio source files were not found")
    patch_app(app); patch_init(init)
    print("v0.3.8 patch applied")
    return 0
if __name__ == "__main__": raise SystemExit(main())
