AI Article Studio v0.3.8 Web AI Quality/Model Sync - Fixed

Fixes the Windows PowerShell 5.1 validation encoding problem in the first v0.3.8 package.
The feature patch itself is unchanged:
- Generation quality changes the recommended model/mode automatically.
- Model dropdown changes generation quality automatically.
- Provider-specific model lists for ChatGPT, Claude, and Gemini.
- Other provider keeps model entry editable.

This package uses ASCII-only inline validation to avoid mojibake in Windows PowerShell.
