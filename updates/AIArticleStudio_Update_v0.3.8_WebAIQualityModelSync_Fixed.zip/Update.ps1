$ErrorActionPreference = 'Stop'
$scriptFile = $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($scriptFile)) { throw 'Run this file with -File .\Update.ps1' }
$packageRoot = Split-Path -Parent $scriptFile
$target = Join-Path $env:LOCALAPPDATA 'AIArticleStudio'
$python = Join-Path $target '.venv\Scripts\python.exe'
if (-not (Test-Path $python)) { throw 'Private Python environment was not found.' }
$patcher = Join-Path $packageRoot 'patch_v038.py'
if (-not (Test-Path $patcher)) { throw 'Patch script is missing.' }

& $python $patcher $target
if ($LASTEXITCODE -ne 0) { throw 'v0.3.8 patch step failed.' }

$appFile = Join-Path $target 'src\ai_article_studio\ui\app.py'
& $python -m py_compile $appFile
if ($LASTEXITCODE -ne 0) { throw 'UI syntax validation failed.' }

# Keep this validation command ASCII-only. Windows PowerShell 5.1 may corrupt
# non-ASCII characters embedded directly in a -c command line.
$validation = "import ai_article_studio; import ai_article_studio.ui.app as app; assert ai_article_studio.__version__ == '0.3.8'; assert hasattr(app,'WEB_AI_MODEL_PROFILES'); assert all(len(app.WEB_AI_MODEL_PROFILES[k]) >= 3 for k in ('ChatGPT','Claude','Gemini')); assert all(v in app.web_ai_models_for(k) for k in ('ChatGPT','Claude','Gemini') for v in app.WEB_AI_DEFAULT_MODEL_BY_QUALITY[k].values()); assert app.web_ai_quality_for_model('ChatGPT', app.WEB_AI_MODEL_PROFILES['ChatGPT'][2][0]) == app.WEB_AI_MODEL_PROFILES['ChatGPT'][2][1]; print('UPDATE OK', ai_article_studio.__version__)"
& $python -c $validation
if ($LASTEXITCODE -ne 0) { throw 'v0.3.8 validation failed.' }

Write-Host ''
Write-Host 'UPDATE SUCCESS' -ForegroundColor Green
Write-Host 'AI Article Studio v0.3.8 Web AI quality/model sync is installed.'
Write-Host 'Restart AI Article Studio.'
